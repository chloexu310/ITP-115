def main():
    concordance = {}
    lineCounter = 1
    fileIn = open("story.txt", "r")
    for line in fileIn:              #one LINE of the file
        line = line.strip()
        wordList = line.split(" ")   #words of a SINGLE in a list

        for word in wordList:
            word = word.strip(".,'?!:;\"")  #remove punctuation
            word = word.lower()
            if word not in concordance:   #we have NOT SEEN this word before
                concordance[word] = [lineCounter]
            else:                       #word is ALREADY in disctionary
                concordance[word].append(lineCounter)

        lineCounter += 1

    #for word in concordance:
    #   print(word, concordance[word])
    keys = list(concordance.keys())
    keys.sort()

    for word in keys:
        print(word,concordance[word])


main()