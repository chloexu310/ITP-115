#Yanyu Xu
#ITP_115, FALL 2019
#Lab 11
#yanyuxu@usc.edu
import random
class Die(object):
    def __init__(self, numSides):
        self.rollValue = 0
        self.sides = numSides


    def roll(self):
        self.rollValue = random.randrange(1, self.sides)


    def __str__(self):
        msg = "Die has " + str(self.sides) + " sides and rolled a " + str(self.rollValue)
        return msg

def calculateSum(die1, die2):
    die1.roll()
    die2.roll()
    print(die1)
    print(die2)
    return die1.rollValue + die2.rollValue



def main():
    default = input("Use the default number of sides for first die(y/n)?")
    if default == "y":
        numSides = 6
        default1 = input("Use the default number of sides for second die(y/n)?")
        if default1 == "y":
            numSides1 = 6
        elif default1 == "n":
            numSides1 = int(input("How many sides?"))
    elif default == "n":
        numSides = int(input("How many sides?"))
        default1 = input("Use the default number of sides for second die(y/n)?")
        if default1 == "y":
            numSides1 = 6
        elif default1 == "n":
            numSides1 = int(input("How many sides?"))

    die1 = Die(numSides)
    die2 = Die(numSides1)

    times = int(input("How many times do you want to roll the die?"))
    for time in range(times):
        calculateSum(die1, die2)
        print("Die has", numSides, "sides and rolled a", die1)
        print("Die has", numSides1, "sides and rolled a", die2)
    print("The sum of Dice 1 and Dice 2 is", die1.rollValue + die2.rollValue)


main()