#Yanyu Xu
#ITP_115, FALL 2019
#A7
#yanyuxu@usc.edu

import random

def main():
    # keep track of total computer/player wins and ties
    countComputer = 0
    countUser = 0
    countTie = 0

    #Create a while loop that runs as long as the user wants to continue the game
    keepGoing = True
    while keepGoing == True:
    #    continueGame()

    #In the loop you should display the menu, get the computer's choice, get the player's choice, and see who won
        #display menue
        displayMenu()

        #get the computer's choice

        #get the player's choice


    #see who won
    # keep track of the score
        computerChoice = getComputerChoice()
        playerChoice = getPlayerChoice()

        run = playRound(computerChoice, playerChoice)
        if run == 1:
            countUser = countUser + 1
        elif run == -1:
            countComputer = countComputer + 1
        elif run == 0:
            countTie = countTie + 1


    # ask the user if they want to continue
    # display the total wins, losses and ties
        keepGoing = continueGame(countUser, countComputer, countTie)





#prints out menu to the user
def displayMenu():
    print("Welcome! Let's play rock, paper, scissors.\n"
          "The rules of the game are:\n"
          "\tRock smashes scissors\n"
          "\tScissors cut paper\n"
          "\tPaper covers rock\n"
          "\tIf both the choices are the same, it's a tie\n")

#gets the computer's random choice returns integer representing choice
def getComputerChoice():
    num = random.randint(0, 2)

    return num



# ask the user for their choice, returns integer representing choice
def getPlayerChoice():
    userInput= int(input("Please choose (0) for rock, (1) for paper or (2) for scissors"))
    return userInput



#uses the two choices and applied the rules of the game to determine a winner, returns integer representing who won

def playRound(computerChoice, playerChoice):

    if computerChoice == 0 and playerChoice == 1:

        print("You chose Paper.\n"
              "The computer chose Rock.\n"
              "Paper covers rock. You wins!")


        return 1

    elif computerChoice == 0 and playerChoice == 2:
        print("You chose Scissors.\n"
              "The computer chose Rock.\n"
              "Rock smashes Scissors. Computer wins!")

        return -1

    elif computerChoice == 0 and playerChoice == 0:
        print("You chose Rock.\n"
              "The computer chose Rock.\n"
              "Both the choices are the same. It is a tie!")

        return 0

    elif computerChoice == 1 and playerChoice == 1:
        print("You chose Paper.\n"
              "The computer chose Paper.\n"
              "Both the choices are the same. It is a tie!")

        return 0

    elif computerChoice == 1 and playerChoice == 0:
        print("You chose Rock.\n"
              "The computer chose Paper.\n"
              "Paper covers rock. Computer wins!")

        return -1

    elif computerChoice == 1 and playerChoice == 2:
        print("You chose Scissors.\n"
              "The computer chose Paper.\n"
              "Scissors cut paper. You wins!")

        return 1

    elif computerChoice == 2 and playerChoice == 1:
        print("You chose Paper.\n"
              "The computer chose Scissors.\n"
              "Scissors cut paper. Computer wins!")

        return -1

    elif computerChoice == 2 and playerChoice == 0:
        print("You chose Rock.\n"
              "The computer chose Scissors.\n"
              "Rock smashes scissors. You wins!")

        return 1

    elif computerChoice == 2 and playerChoice == 2:
        print("You chose Scissors.\n"
              "The computer chose Scissors.\n"
              "Both the choices are the same. It is a tie!")

        return 0



#asks the user whether they want t0 continue or not, returns boolean
def continueGame(countUser, countComputer, countTie):
    wantsContinue = input("Do you want to continue playing? Enter (y) for yes or (n) for no")
    while wantsContinue.lower() != "y" and wantsContinue.lower() != "n":
        wantsContinue = input("Do you want to continue playing? Enter (y) for yes or (n) for no")
    if wantsContinue.lower() == "y":
        return True

    elif wantsContinue.lower() == "n":
        print("You won", countUser, "game(s).")
        print("The computer won", countComputer, "game(s).")
        print("You tied with the computer", countTie, "time(s).")
        print("Thanks for playing!")




main()


