def main():

#give inputs and variables
#string
    name = input("Enter your name")
    location=input("Where are you from?")
#integer
    brothers=int(input("How many brother do you have?"))
    sisters=int(input("How many sister do you have?"))
#another string
    mood=input("How's your day?")
    reason=input("why do you feel this way?")
#float
    height=float(input("How tall are you in decimal?"))
#another string
    pet=input("What pets do you have?")
#last integer
    animal=int(input("How many pets do you have?"))

#final print
    print("My name is", name, "I am from", location, ".", "I have", brothers, "brothers and I have",
          sisters, "sisters. In total, I have", sisters+brothers, "siblings. My height is"
          , height,". I have", animal, "pet", pet, ". I feel", mood,
          "today, because", reason, ". I believe tomorrow can be better"
          )




main()