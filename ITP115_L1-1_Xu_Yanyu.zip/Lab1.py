#Yanyu Xu
#ITP 115, Spring 2018
#Lab 1
#yanyuxu@usc.edu

def main():
    print("You don;t frighten us," + "English pig-dog!")
    print("Go and boil your bottoms," + "sons of a silly person!")
    print("-Monty Python and the Holy Grail")

#i tried many times, i do not know how to do the box...

    month = input("What month are we in?")
    print(month, "May")

    weekday = input("What day is it?")
    print(weekday, "Wednesday")

    dayoftheMonth = input("What day of the month is today?")
    print(dayoftheMonth, "4")

    today = int( input("What is today's date and day" + "?" ))
    print("today is", month, dayoftheMonth, "and tomorrow will be May 5")

main()