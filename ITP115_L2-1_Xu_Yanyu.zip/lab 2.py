#Yanyu Xu
#ITP 115, Spring 2018
#Lab 1
#yanyuxu@usc.edu

def main(): #defines a block
  #temperature
    temp = int(input("What temperature do you want?"))

#if you plan to create a variable INSIDE a block AND you want
#to use the variable later OUTSIDE the block, you must
# create it before you enter the block

#make new variable
    tempOutput= ""    #initialize the value before entering if
    if temp >= 100:
      tempOutput = "hot"
    elif temp < 100:
      tempOutput = "cold"

    #rest of your code


    size = input("What size coffee do you want (S, M, L)?")
    if size == "S":
      sizeOutput = "Small"
    elif size == "M":
      sizeOutput = "Medium"
    elif size == "L":
      sizeOutput = "Large"
    else:
      print("we don't have that")




    typeofBean = input("What type of beans/blend would you like?")
    if typeofBean == " Costa Rica":
      bean = "Costa Rica"
    else:
      bean ="Sorry, we don't have it"

    creamAdding = input( " Would you like room for cream(y/n)")
    if creamAdding== "yes":
       cream = "with cream"
    else:
       cream= "with no cream"

    print("You ordered a",sizeOutput,tempOutput,bean,"with",cream)



main()