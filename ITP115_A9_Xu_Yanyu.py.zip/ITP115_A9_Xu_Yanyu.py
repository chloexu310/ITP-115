#Yanyu Xu
#ITP_115, FALL 2019
#Assignment 9
#yanyuxu@usc.edu


def main():
    #prompy user for which file to open
    # Ask user for filename to store results
    # Provide an option for the user to select which year they would like to evaluate
        # Let the user try again if they enter a year other than 2008/2009

    print("Welcome to EPA Mileage Calculator")
    userInput = int(input("What year would you like to view data for?(2008 or 2009):"))
    while userInput != 2008 and userInput != 2009:
        print("*Invalid input, please try again!")
        userInput = int(input("What year would you like to view data for?(2008 or 2009):"))


    if userInput == 2008:
        filenameInput = input("Enter the filename to save results to:")

        while filenameInput != "epaVehicleData2008.csv":
            filenameInput = input("Enter the filename to save results to:")

        if filenameInput == "epaVehicleData2008.csv":
            print("Operation Success! Mileage data had been saved to results.txt")
            print("Thanks, and have a great day!")



    elif userInput == 2009:
        filenameInput = input("Enter the filename to save results to:")
        while filenameInput != "epaVehicleData2009.csv":
            filenameInput = input("Enter the filename to save results to:")

        if filenameInput == "epaVehicleData2009.csv":

            print("Operation Success! Mileage data had been saved to results.txt")
            print("Thanks, and have a great day!")




    #open file

    fileIn = open(filenameInput, "r")
    #skip header row
    fileIn.readline()
    overalllist = []
    for line in fileIn:
        line = line.strip()
        dataList = line.split(",")
        # 'van', 'minivan', or 'truck'
        if "VAN" not in dataList [0] and "MINIVAN" not in dataList [0] and "TRUCK" not in dataList [0]:
            overalllist.append(dataList)

    fileIn.close()

    # Find all cars with the minimum MPG and write them to text file
    # Find all cars with the maximum MPG and write them to text file
    # find min/max mpg in list
    maxlist = []
    minlist = []
    cartypemax = []
    cartypemin = []
    max = 0
    min = 1000

    for eachcar in overalllist:
        if int(eachcar[8]) < min:
            min = int(eachcar[8])
            minlist.append(min)
        elif int(eachcar[8]) == min:
            cartypemin.append(eachcar[1] + " " + eachcar[2])
            minlist.append(min)
        elif int(eachcar[8]) > max:
            max = int(eachcar[8])
            maxlist.append(max)
        elif int(eachcar[8]) == max:
            cartypemax.append(eachcar[1] + " " + eachcar[2])
            maxlist.append(max)

    maxcartype = (" \n".join(cartypemax))
    mincartype = (" \n".join(cartypemin))

    #open output file
    fileOut = open("results.txt", "w")
    print("EPA City MPG Calculator", "(", userInput ,")", file=fileOut)
    print("------------------------------", file=fileOut)
    print("Maximum Mileage (city):", max, file=fileOut)
    print(maxcartype, file=fileOut)
    print("Minimum Mileage (city):", min, file=fileOut)
    print(mincartype, file=fileOut)

    fileOut.close()





#Extra Credit:
#Ask the user if they would like see mileage data from other vehicles types
#Then write the data accordingly. Be sure to error check




main()