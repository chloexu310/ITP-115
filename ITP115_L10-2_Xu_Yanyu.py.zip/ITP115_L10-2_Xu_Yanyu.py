#Yanyu Xu
#ITP_115, FALL 2019
#Lab 10-2
#yanyuxu@usc.edu

def readDictionaryFile(dictionary):
    inputFile = open(dictionary, "r")
    wordsList = []
    for line in inputFile:
        line = line.strip()
        wordsList.append(line)
    inputFile.close()
    return wordsList


def findWord(wordsList, searchWord):
    if searchWord in wordsList:
        return True
    else:
        return False



def writeFile(outputList, fileName):
    #open output file
    fileOut = open(fileName, "w")
    for word in outputList:
        print(word, file=fileOut)

    fileOut.close()





def main():
    outputList = []
    print("Welcome to the Word Checker!")
    fileopen = input("Enter the name of the file you wish to read in:")
    if fileopen == "dictionary.txt":
        readDictionaryFile(fileopen)
        wordsList = readDictionaryFile(fileopen)
    else:
        fileopen = input("Enter the name of the file you wish to read in:")

    output = input("Enter the name of the file you wish to write in:")
    check = input("Enter the word you wish to check:")
    findWord(wordsList, check)
    if findWord(wordsList, check) == True:
        outputList.append(check)
        writeFile(outputList, output)
        print(check, "is already in the dictionary.")
        print("The word list has been written to", output)
    else:
        outputList.append(check)
        writeFile(outputList, output)
        print(check, "had been added to the dictionary.")
        print("The word list has been written to", output)




main()