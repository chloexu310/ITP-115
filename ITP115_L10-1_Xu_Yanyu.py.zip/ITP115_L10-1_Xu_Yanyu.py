#Yanyu Xu
#ITP_115, FALL 2019
#Lab 10-1
#yanyuxu@usc.edu

def readDictionaryFile(dictionary):
    inputFile = open(dictionary, "r")
    dictionaryList = []
    for line in inputFile:
        line = line.strip()
        dictionaryList.append(line)
    inputFile.close()
    return dictionaryList

def readTextFile(passage):
    inputFile = open(passage, "r")
    textList = []
    for line in inputFile:
        line = line.strip()
        textList.append(line)
    inputFile.close()
    return textList

def findErrors(dictionaryList,textList):
    errorList = []
    for item in dictionaryList:
        if item != textList:
            errorList.append(item)
    return errorList




def printErrors(errorList):
    print("The misspelled words from the file are:")
    for item in errorList:
        print(item)




def main():
    print("Welcome to the Spell Checker!")

    userinput = input("Please enter the dictionary file you wish to read in:")
    dictionaryList = readDictionaryFile(userinput)
    anotherinput = input("Please enter the text file you wish to read in:")
    textList = readTextFile(anotherinput)
    errorList = findErrors(dictionaryList, textList)
    printErrors(errorList)



main()