#Yanyu Xu
#ITP_115, FALL 2019
#A6
#yanyuxu@usc.edu
def main():
    TOTAL_SEATS = 10 #the plane's total capacity which doesn't change
    numFilledSeats = 0 #number of seats filled so far
    listOfSeats = ["Empty", "Empty", "Empty", "Empty", "Empty", "Empty","Empty","Empty","Empty","Empty"]
    firstClass = 0 #the total first class filled so far
    economyClass = 4 #the starting economy class


    while TOTAL_SEATS != numFilledSeats:
        print("1: Assign Seats. \n"
              "2: Print Seat Map. \n"
              "3: Print Boarding pass. \n"
              "-1: Quit.")

        userInput = int(input("Please enter the service you are looking for: "))

        if userInput == 1:
            #firstNameInput = input("Please enter your name: ")
            #del listOfSeats[numFilledSeats]
            #listOfSeats.insert(numFilledSeats, firstNameInput)
            #TOTAL_SEATS = TOTAL_SEATS - 1
            #numFilledSeats = numFilledSeats + 1

            choseSeat = int(input("Type 1 for First class or type 2 for Economy"))
            if choseSeat == 1:
                firstNameInput = input("Please enter your name: ")
                if firstClass <= 3:
                    del listOfSeats[firstClass]
                    listOfSeats.insert(firstClass, firstNameInput)
                    firstClass = firstClass + 1
                elif firstClass > 3:
                    ask = input("Sorry, we are out of first class seats. Would you like to try economy class? (y/n)")
                    if ask.lower() == "y":
                        del listOfSeats[economyClass]
                        listOfSeats.insert(economyClass, firstNameInput)
                        economyClass = economyClass + 1
                    else:
                        print("Next flight leaves in 3 hours")

            elif choseSeat == 2:
                firstNameInput = input("Please enter your name: ")
                if economyClass < 10:
                    del listOfSeats[economyClass]
                    listOfSeats.insert(economyClass, firstNameInput)
                    economyClass = economyClass + 1
                elif economyClass >= 10:
                    askAgain = input("Sorry, we are out of economy class seats. Would you like to try first class? (y/n)")
                    if askAgain.lower() == "y":
                        del listOfSeats[firstClass]
                        listOfSeats.insert(firstClass, firstNameInput)
                        firstClass = firstClass + 1
                    else:
                        print("Next flight leaves in 3 hours")
        elif userInput == 2:
            print("***************************************"
                  "\n    Seat #1:", listOfSeats[0],
                  "\n    Seat #2:", listOfSeats[1],
                  "\n    Seat #3:", listOfSeats[2],
                  "\n    Seat #4:", listOfSeats[3],
                  "\n    Seat #5:", listOfSeats[4],
                  "\n    Seat #6:", listOfSeats[5],
                  "\n    Seat #7:", listOfSeats[6],
                  "\n    Seat #8:", listOfSeats[7],
                  "\n    Seat #9:", listOfSeats[8],
                  "\n    Seat #10:", listOfSeats[9],
                  "\n***************************************")

        elif userInput == 3:
            choiceInput = int(input("Type 1 to get Boarding Pass by seat number \n"
                              "Type 2 to get Boarding Pass by name"))
            if choiceInput == 1:
                seatNumber = int(input("What is the seat number:"))
                if seatNumber > 10 or seatNumber < 0:
                    print("Invalid number-no boarding pass found")
                else:
                    print("======= BOARDING PASS ======= \n"
                       "    Seat # :", seatNumber ,
                        "\n    Passenger Name:", listOfSeats[seatNumber-1], #this is not correct,
                       "\n=============================")
            elif choiceInput == 2:
                findNameInput = input("Please enter your name: ")
                if findNameInput in listOfSeats:
                    print("======= BOARDING PASS ======= \n"
                      "     Seat # :", listOfSeats.index(findNameInput) + 1,
                      "\n   Passenger Name:", findNameInput,
                      "\n=============================")
                elif findNameInput not in listOfSeats:
                    print("No passenger with name", findNameInput, "was found")

        elif userInput == -1:
            print("Have a nice day!")
            break

        else:
            Input = int(input("Please enter choice: "))









main()