#Yanyu Xu
#ITP_115, FALL 2019
#Lab 9
#yanyuxu@usc.edu
import random
numberOfHead = 0
numberOfFlip = 0

def coin():
    for x in range(0,3):
        value = random()
        print(value)
        numberOfFlip = numberOfFlip + 1
        if value == 1:
            numberOfHead = numberOfHead + 1
            return head
        elif value == 2:
            numberOfHead = numberOfHead + 0
            return tails



def experiment():
    if numberOfHead == 3:
        int1 == numberOfFlip
        return int1


def main():
    keepGoing = True
    while keepGoing == True:
        number = numberOfFlip / numberOfHead
        print("The average for 3 heads in a row is:", number)



main()