#Yanyu Xu
#ITP_115, FALL 2019
#Lab 12-1
#yanyuxu@usc.edu

MAX_COURSES = 6

class Student(object):
    def __init__(self, inputName, inputId): #doesn't take class list
        self.name = inputName
        self.id = inputId
        self.courses = []    #students starts off in 0 courses

    def getName(self):
        return self.name

    def getId(self):
        return self.id

    def setName(self, newName):
        if newName.isalpha() == True and newName != "":
            self.name = newName

        else:
            print("Invalid name")

    def setId(self, newId):
        if newId > 0:
            self.id = newId
        else:
            print("Invalid id")

    def getCourses(self):
        return self.courses

    def getNumberOfCourses(self):
        return len(self.courses)

    def addCourse(self, course):
        #if len(self.courses) >= 6:
        if self.getNumberOfCourses() >= MAX_COURSES:
            return False
        else:
            self.courses.append(course)
            return True

    def __str__(self):
        #str returns a str variable; it NEVER calls print()
        msg = "Student: " + self.getName() + ", ID: " + str(self.getId())
        msg += " enrolled in " + str(self.getNumberOfCourses()) + " courses: "
        for course in self.courses:
            msg += """-""" + course
        return msg

def printStudents(studentList):
    studentList = [Student("Tiffany", "40"),Student("Isaaca", "41"),Student("Huy", "42"),Student("Brandon", "43")]
    for student in studentList:
        print(student.getName())

def main():
    studentList = []

    tiffany = Student("Tiffany", "40")
    isaaca = Student("Isaaca", "41")
    huy = Student("Huy", "42")
    brandon = Student("Brandon", "43")


    keepGoing = True
    while keepGoing == True:
        print("Welcome to the student registration system!")
        print("Students")
        print("     1) Tiffany")
        print("     2) Isaaca")
        print("     3) Huy")
        print("     4) Brandon")
        listInput = int(input("Select a student from the list(1-4):"))
        if listInput == 1:
            tiffany = Student("Tiffany", "40")
            courseInput = input("Enter the course the student is registering for: ")
            if courseInput == "ITP 115":
                tiffany.addCourse("ITP 115") == True
                print("Course registration successful")
        elif listInput == 2:
            isaaca = Student("Isaaca", "41")
            courseInput = input("Enter the course the student is registering for: ")
            if courseInput == "ITP 115":
                isaaca.addCourse("ITP 115") == True
                print("Course registration successful")
        elif listInput == 3:
            huy = Student("Huy", "42")
            courseInput = input("Enter the course the student is registering for: ")
            if courseInput == "ITP 115":
                huy.addCourse("ITP 115") == True
                print("Course registration successful")
        elif listInput == 4:
            brandon = Student("Brandon", "43")
            courseInput = input("Enter the course the student is registering for: ")
            if courseInput == "ITP 115":
                brandon.addCourse("ITP 115") == True
                print("Course registration successful")

        registerAgain = input("Would you like to continue registering? (y/n): ")
        if registerAgain.lower() != "y" and registerAgain.lower() != "n":
            print("Invalid answer")
        elif registerAgain.lower() == "y":
            ""
        elif registerAgain.lower() == "n":
            break

    print(tiffany)
    print(isaaca)
    print(huy)
    print(brandon)








main()

