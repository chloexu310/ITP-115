#Yanyu Xu
#ITP_115, FALL 2019
#Assignment 8
#yanyuxu@usc.edu

import TicTacToeHelper


def isValidMove(boardList, spot):
    if spot in range(0, 9):
        if boardList[spot] != "x" and boardList[spot] != "o":
            return True
        else:
            return False
    else:
        return False

def updateBoard(boardList, spot, playerLetter):
#a string representing the user's letter(x or o)
    del boardList[spot]
#someList.insert(i,value) - insert value at position i
    boardList.insert(spot, playerLetter)
    TicTacToeHelper.printUglyBoard(boardList)


def playGame():
    boardList = ["0", "1", "2", "3", "4", "5", "6", "7", "8"]
    TicTacToeHelper.printUglyBoard(boardList)
    move_counter = 0
    while TicTacToeHelper.checkForWinner(boardList, move_counter) == "n":
        if move_counter % 2 == 0:
            spot = int(input("Player x, pick a spot"))
            if isValidMove(boardList, spot) == True:
                updateBoard(boardList, spot, "x")
                move_counter += 1
            elif isValidMove(boardList, spot) == False:
                print("Invalid move, please try again.")


        elif move_counter % 2 == 1:
            spot = int(input("Player o, pick a spot"))
            if isValidMove(boardList, spot) == True:
                updateBoard(boardList, spot, "o")
                move_counter += 1
            elif isValidMove(boardList, spot) == False:
                print("Invalid move, please try again.")


    TicTacToeHelper.checkForWinner(boardList, move_counter)


    #now the "move" is basically complete, so also:
    #call the checkforwinner function on your board
    if TicTacToeHelper.checkForWinner(boardList, move_counter) == "x":
        print("Game Over")
        print("Player x is the winner!")
    elif TicTacToeHelper.checkForWinner(boardList, move_counter) == "o":
        print("Game Over")
        print("Player o is the winner!")
    elif TicTacToeHelper.checkForWinner(boardList, move_counter) == "s":
        print("Game Over")
        print("Stalemate reached!")





def main():
    playGame()
    keepGoing = True
    while keepGoing == True:
        wantsContinue = input("Do you want to continue playing? Enter (y) for yes or (n) for no")
        if wantsContinue.lower() == "y":
            playGame()
        elif wantsContinue.lower() == "n":
            print("Goodbye")
            break
        elif wantsContinue.lower() != "y" and wantsContinue.lower() != "n":
            wantsContinue = input("Do you want to continue playing? Enter (y) for yes or (n) for no")



main()