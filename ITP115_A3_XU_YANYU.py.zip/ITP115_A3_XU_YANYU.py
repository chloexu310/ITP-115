#Yanyu Xu
#ITP 115, Spring 2018
#Assignment 3
#yanyuxu@usc.edu

def main():
    #set for large
    wantsToContinue = "y"
    large = -1
    number = True
    #set for small
    small = 100000000000000000000000000000000
    print("Input an integer greater than or equal to 0 or -1 to quit:")

    while number == True:
        nextNum = int(input("Enter a number:"))
        if nextNum < 0:
            number = False
        if nextNum > large:
            large = nextNum
        if nextNum < small and nextNum is not -1:
            small = nextNum
    print("The largest number is", large)
    print("The smallest number is", small)
    print("The average number is", (large+small) / 2)

    wantsToContinue = "y"
    while wantsToContinue.lower() =="y":
        nextNum = int(input("Enter a number:"))
        if nextNum < 0:
                break
        if nextNum > large:
                large = nextNum
        if nextNum < small and nextNum is not -1:
                small = nextNum

        print("The largest number is", large)
        print("The smallest number is", small)
        print("The average number is", (large + small) / 2)

        wantsToContinue = input("Would you like to enter another set of numbers?(y/n):")
        while wantsToContinue.lower() !="y" and wantsToContinue.lower() != "n":
            wantsToContinue = input("Oopsa! Would you like to enter another set of numbers?(y/n):")



    print("\nGoodbye!")













main()