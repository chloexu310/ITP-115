#Yanyu Xu
#ITP_115, FALL 2019
#A5-PART2
#yanyuxu@usc.edu
import random
def main():
    # create originial alphabet
    alpha = "abcdefghijklmnopqrstuvwxyz"
    alphabetList = list(alpha)
    encrypt = []
    decrypt = []


    #get user input
    userMsg=input("Enter a message:")
    userNum=int(input("Enter a number to shift by (0-25):"))

    # cipher input
    stay = alphabetList[userNum:26]
    shuffle = alphabetList[0:userNum]

    #create cipher by adding back
    cipher = stay + shuffle
    ciphernew = "".join(cipher)

    print("Encrypting message...")


    # we can use the index number to get the one we want
    for letter in userMsg.lower():
        if letter in alphabetList:
            old = alpha.index(letter)
            new = cipher[old]
            encrypt.append(new)
            encrypt1 = "".join(encrypt)
    print("Encrypted message:", encrypt1)


    print("Decrypting message...")
    for letter in encrypt:
        if letter in ciphernew:
            past = ciphernew.index(letter)
            new1 = alpha[past]
            decrypt.append(new1)
    print("Decrypted message:", "".join(decrypt))
    print("Original message:", userMsg)




main()