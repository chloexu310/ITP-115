#Yanyu Xu
#ITP_115, FALL 2019
#A5 PART1
#yanyuxu@usc.edu
import random
def main():
    #start w/ empty string for [looks through random word]
    #build the word
    words = ["pumpkin", "happy", "python"]
    word = random.choice(words)
    #turn string into a list
    ltrList = list(word)
    jumb = ""
    count = 0

    # pick a random letter add it to jumbled word delete that random letter

    for letter in range(len(word)):
        questioninput = random.choice(ltrList)
        ltrList.remove(questioninput)
        jumb += questioninput

    print("The jumbled word is: ", jumb)
    question = input("Please enter your guess:")

    while question != word:
        print("Try again.")
        question = input("Please enter your guess:")
        count = count + 1
    else:
        count = count + 1
        print("You got it!")
        print("It took you", count, "tries")

main()