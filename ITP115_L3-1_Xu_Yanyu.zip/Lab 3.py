def main():

    limit = int(input("What do you want to count to?"))
    num = 0
    numSpaces = 0
    while num>= limit:
        num = numSpaces + 1
        print(" "*numSpaces)
        numSpaces = 2 *numSpaces - 2

    print(" "*numSpaces,"^"*num," "*numSpaces)

















main()