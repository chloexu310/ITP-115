#Yanyu Xu
#ITP_115, FALL 2019
#A10-extra
#yanyuxu@usc.edu

#Animal Class


class Animal(object):
    # Constructor Method
    # __init__
    def __init__(self, animalHunger,animalHappy,animalHealth,animalEnergy,animalAge,animalName,animalSpecies):
        self.name = animalName
        self.health = int(animalHealth)
        self.happiness = int(animalHappy)
        self.hunger = int(animalHunger)
        self.energy = int(animalEnergy)
        self.age = int(animalAge)
        self.species = animalSpecies

    def getNmae(self):
        return self.name

    def getHealth(self):
        return self.health

    def Happniess(self):
        return self.happiness

    def Hunger(self):
        return self.hunger

    def Energy(self):
        return self.energy

    def Age(self):
        return self.age

    def Species(self):
        return self.species

    # Instance Methods
    # Play
    def Play(self):
        self.happiness += 10
        self.hunger += 5
        if self.happiness > 100:
            self.happiness = 100
        elif self.happiness < 0:
            self.happiness = 0
        elif self.hunger > 100:
            self.hunger = 100
        elif self.hunger < 0:
            self.hunger = 0

    # feed
    def Feed(self):
        self.hunger = self.hunger - 5
        if self.hunger > 100:
            self.hunger = 100
        elif self.hunger < 0:
            self.hunger = 0


    # giveMedicine
    def giveMedicine(self):
        self.happiness = self.happiness - 20
        self.health += 20

        if self.happiness > 100:
            self.happiness = 100
        elif self.happiness < 0:
            self.happiness = 0
        elif self.health > 100:
            self.health = 100
        elif self.health < 0:
            self.health = 0

    # sleep
    def Sleep(self):
        self.energy += 20
        self.age += 1

        if self.energy > 100:
            self.energy = 100
        elif self.energy < 0:
            self.energy = 0
        elif self.age > 100:
            self.age = 100
        elif self.age < 0:
            self.age = 0

    # __str__
    def __str__(self):

        msg = "Name:" + self.name + " the " + self.species
        msg += "\nHealth:" + str(self.health)
        msg += "\nHappiness:" + str(self.happiness)
        msg += "\nHunger:" + str(self.hunger)
        msg += "\nEnergy:" + str(self.energy)
        msg += "\nAge:" + str(self.age)
        msg += "\n*****************************************"
        return msg



#define function:
#loadAnimals
def loadAnimals(fileName):

    inputFile = open(fileName, "r")
    animalList = []
    for line in inputFile:
        line = line.strip()
        a = line.split(",")
        animalObject = Animal(int(a[0]), int(a[1]),int(a[2]),int(a[3]),int(a[4]),a[5], a[6])
        animalList.append(animalObject)
    inputFile.close()

    return animalList



#displayMenu
def displayMenu():
    print("1) Play")
    print("2) Feed")
    print("3) Give Medicine")
    print("4) Sleep")
    print("5) Print an Animal's stats")
    print("6) View All Animals")
    print("7) Exit")

#selectAnimal
def selectAnimal(animalList):
    #print("1) Ollie the Bunny")
    #print("2) Murdock the French Bulldog")
    #print("3) Socks the Cat")
    #print("4) Peewee the Turtle")
    #print("5) Milo the Labrador")
    animalDisplayIndex = 1
    for line in animalList:
        print(str(animalDisplayIndex) + ") " + line.name + " the " + line.species)
        animalDisplayIndex +=1
    ask = int(input("Please select an animal from the list (enter the 1-5)"))
    while ask >= 5 or ask <= 0:
        print("*Invalid selection, please try again")
        ask = int(input("Please select an animal from the list (enter the 1-5)"))

    return animalList[ask-1]

def saveFile(outputList, fileName):
    #open output file
    fileOut = open(fileName, "w")
    for word in outputList:
        print(word.hunger,",", word.happiness,",", word.health,",",word.energy,",", word.age,",", word.name,",",word.species, file=fileOut)

    fileOut.close()


#main
def main():
    animal = loadAnimals("animals.csv")
    print("Welcome to the Animal Daycare! Here is what we can do: ")
    #ollie = Animal("Ollie the Bunny", 85, 50, 75, 60, 5)
    #murdock = Animal("Murdock the French Bulldog", 80, 70, 60, 55, 3)
    #Socks = Animal("Socks the Cat", 75, 55, 20, 70, 1)
    #Peewee = Animal("Peewee the Turtle", 65, 45, 30, 15, 10)
    #Milo = Animal("Milo the Labrador", 70, 75, 40, 80, 6)
    KeepGoing = True
    while KeepGoing == True:
        displayMenu()
        selection = int(input("Please make a selection: "))
        if selection > 7 or selection <= 0:
            print("*Invalid selection, please try again")
            displayMenu()
        elif selection == 1:
            choice = selectAnimal(animal)
            choice.Play()
            print("You played with " + choice.name + " the " + choice.species)


        elif selection == 2:
            choice = selectAnimal(animal)
            choice.Feed()
            print("You fed with " + choice.name + " the " + choice.species)


        elif selection == 3:
            choice = selectAnimal(animal)
            choice.giveMedicine()
            print("You gave " + choice.name + " the " + choice.species + " some medicine!")


        elif selection == 4:
            choice = selectAnimal(animal)
            choice.Sleep()
            print(choice.name + " the " + choice.species + " took a nap!")


        elif selection == 5:
            choice = selectAnimal(animal)
            select = Animal(choice.hunger, choice.happiness, choice.health, choice.energy, choice.age, choice.name,choice.species)
            print(select)

        elif selection == 6:
            for all in animal:
                print(all)


        elif selection == 7:
            output = input("Enter the name of the file you wish to write in:")
            saveFile(animal, output)
            print("Goodbye!")
            break

main()