#YANYU XU
#ITP 115, SPRING 2020
#Lab 5-1
#yanyuxu@usc.edu

import random

def main():
    articles = ["the", "a"]
    nouns = ["chair", "turtle", "jack"]
    verbs = ["eat", "sleep", "dance"]

    #menu-we want to loop to run AT LEAST once
    menuChoice = 0 #default

    while menuChoice != 5:
        print("Welcome to the Sentence Generator")
        print("Menu")
        print("1) View Words")
        print("2) Add Words")
        print("3) Remove Words")
        print("4) Generate Sentence")
        print("5) Exit")

        menuChoice = int(input("Enter choice: "))

        #error checking with while loop to make sure they enter 1-5

        if menuChoice == 1:  #view
            print("articles:", articles)
            print("nouns", nouns)
            print("verbs", verbs)
        elif menuChoice == 2: #add
            wordToAdd = input("Enter 1) for nouns or 2) for verbs")
            if wordToAdd == "1":
                nounsToAdd = input("Enter the word: ")
                nouns.append(nounsToAdd)
            elif wordToAdd == "2":
                verbsToAdd = input ("Enter the word: ")
                verbs.append(verbsToAdd)
            elif wordToAdd != "1" and wordToAdd != "2":
                print("Enter is not valid")


        elif menuChoice == 3: #remove
            wordToRemove = input("Enter 1) for nouns or 2) for verbs")
            if wordToRemove == "1":
                nounsToRemove = input("Enter the word: ")
                if nounsToRemove in nouns:  # make sure its in there
                    nouns.remove(nounsToRemove)
                else:
                    print("That is not in the list")
            elif wordToRemove == "2":
                verbsToRemove = input("Enter the word: ")
                if verbsToRemove in verbs:  # make sure its in there
                    verbs.remove(verbsToRemove)
                else:
                    print("That is not in the list")
            elif wordToRemove != 1 and wordToRemove != 2:
                print("Enter 1) for nouns or 2) for verbs")


        elif menuChoice == 4: #generate
            print(random.choice(articles), random.choice(nouns),
                  random.choice(verbs), random.choice(articles),
                  random.choice(nouns))

        elif menuChoice == 5:
            print("Program will now exit")









main()