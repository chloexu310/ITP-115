def main():
    print("This is a psychology test to show different personality you have, please follow the following "
          "instruction to began your journey to continue")
    print("Background story: One day, a prince went to a forest. As he walked more deeper and deeper into the woods"
          "he is hungry and thirsty. While he is trying to find some places to get food, a lake appears in front of him."
          "He runs to the lake and there is a wooden house appeared....")

    WoodenHouse=input('''What do you think the prince will do? 
                      a) knock the door and see if anyone is in the wooden house
                      b) try to use leaves and branches to fish around the lake
                      c) he thinks the wooden house is too dangerous, so he walks away from it''')

    if WoodenHouse == "a":
        personality = "curious"

        GoWoodHouse = input('''You knocked the house but no one is there. You secretly went into the house and you saw there is a princess sleeping in the house. You try to wake her up but you can't
                            What do you choice to do?
                            a) Kiss her
                            b) Take her back to your castle
                            c) leave her alone and leave''')
        if GoWoodHouse == "a":
            personality1 = "likes to help others"
        elif GoWoodHouse == "b":
            personality1 = "likes to depend on other's help"
        elif GoWoodHouse == "c":
            personality1 = "is independent and selfish"


        print("Now, it is time for you to know what your persoality is. We collected over 100 billion data and get the most"
          "precise decision we can.")
        print("It seems you are a person who is", personality, "From your second choice, you are someone who", personality1)


    if WoodenHouse == "b":
        personality = "independent"

        Fish=input('''You are trying to get some fish from the lake. However, it seems there no fish in the lake. You accidentally see a snake,
                   What will you choice to do?
                   a) Kill the snake with your sword
                   b) Run away
                   c) Catch it and cook it later as your food ''')
        if Fish == "a":
            personality2 = "is seflish"
        elif Fish == "b":
            personality2 = "escapes from the reality"
        elif Fish == "c":
            personality2 = "likes strategical plan"


        print("Now, it is time for you to know what your persoality is. We collected over 100 billion data and get the most"
      "precise decision we can.")
        print("It seems you are a person who is", personality, "From your second choice, you are someone who", personality2)


    if WoodenHouse == "c":
        personality = "playing safe"

        Walkaway = input('''You went to a different direction and try to find food. However, you are too tired. You have been walking
                         for so long time. You suppose to challenge yourself to stay in the forest for several days. 
                         However, now you are too hungry and tired. Now you have to make a choice for your survive
                         a) Go back to lake and fish
                         b) Go back to your castle and fail the challenge
                         c) Eat some insects first''')
        if Walkaway == "a":
            personality3 = "Swings back and forth, do not know what you really want"
        elif Walkaway == "b":
            personality3 = "Does not brave enough and not mature"
        elif Walkaway == "c":
            personality3 = "lives in the presence"

        print("Now, it is time for you to know what your persoality is. We collected over 100 billion data and get the most"
          "precise decision we can.")
        print("It seems you are a person who is", personality, "From your second choice, you are someone who", personality3)







main()