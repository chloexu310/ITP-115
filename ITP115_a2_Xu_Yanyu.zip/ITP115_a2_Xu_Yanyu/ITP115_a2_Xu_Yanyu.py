#Part 1-Harry Potter Vending Machine
def main():
    #price
    Butterbeer = 58
    Quill = 10
    TheDailyProphet = 7
    BookofSpells = 400

    #Item choice
    Item=input('''Please select an item from the vending machine
               a) Butterbeer: 58 knuts
               b) Quill: 10 knuts
               c) The Daily Prophet: 7 knuts
               d) Book of Spells: 400 knuts''')



    if Item.lower() == "a":
        itemOutPut = "Butterbeer"
        itemPrice = Butterbeer
    elif Item.lower() == "b":
        itemOutPut = "Quill"
        itemPrice = Quill
    elif Item.lower() == "c":
        itemOutPut = "TheDailyProphet"
        itemPrice = TheDailyProphet
    elif Item.lower() == "d":
        itemOutPut = "BookofSpells"
        itemPrice = BookofSpells
    else:
        print("You have entered an invalid option. You will be given a Butterbeer for", Butterbeer, "knuts")
        itemOutPut = "Butterbeer"
        itemPrice = Butterbeer

    #Ask intagram
    Insta = input("Will you share this on Instagram? (y/n)")

    if Insta.lower() == "y":
        print("Thanks! You get 5 knuts off your purchase")
        coupon= 5
    elif Insta.lower() == "n":
        print("Ok, let's continue to purchase")
        coupon = 0
    else:
        print("You have entered an invalid option. No coupon will be used")
        coupon = 0


    #final calculate
    print("You bought a", itemOutPut, "for", itemPrice, "knuts (with coupon of", coupon, "knuts) and paid with one galleon")
    print("Here is your change (", 493-itemPrice-coupon,"knuts):")
    print("Sickles:", (493-itemPrice-coupon)//29)
    print("Knuts:", (493-itemPrice-coupon)%29)











main()
