#comments about name and email and stuff
import random

def main():
    #use while loop to ask user for word
    userInput = input("Please type in a word:")

    while len(userInput) <= 0:
        #ask user for input again
        userInput = input("Please type in a word:")
    print("User Input is:", userInput)

    originalValue = userInput
    #if word is 4 letters or more, add random vowel
    if len(userInput) > 3:
        userInput = userInput + random.choice("aeiou") #get random letter out of string
    #if word is 3 letters or less, add "en" to the end
    if len(userInput) < 4:
        userInput += "en" #add "en" to the end


    #loop to change all "k"s to "c"s
    elvishWord = ""
    #loop through all letters in original word
    for letter in userInput:
    # if current letter is a k, then add a c
        if letter.lower() == "k":
    #otherwise/else add the original letter
            elvishWord += "c"
    #add letter to new String called
        else:
            elvishWord += letter

    # ask user if want to continue
    print("End word:", elvishWord)

    Continue = input("Would you like to translate another word?(y/n)")

    if Continue == "y":
        # use while loop to ask user for word
        userInput = input("Please type in a word:")

        while len(userInput) <= 0:
            # ask user for input again
            userInput = input("Please type in a word:")
        print("User Input is:", userInput)

        originalValue = userInput
        # if word is 4 letters or more, add random vowel
        if len(userInput) > 3:
            userInput = userInput + random.choice("aeiou")  # get random letter out of string
        # if word is 3 letters or less, add "en" to the end
        if len(userInput) < 4:
            userInput += "en"  # add "en" to the end

        # loop to change all "k"s to "c"s
        elvishWord = ""
        # loop through all letters in original word
        for letter in userInput:
            # if current letter is a k, then add a c
            if letter.lower() == "k":
                # otherwise/else add the original letter
                elvishWord += "c"
            # add letter to new String called
            else:
                elvishWord += letter

        # ask user if want to continue
        print("End word:", elvishWord)

        Continue = input("Would you like to translate another word?(y/n)")

    else:
        print("Goodbye! Have a nice day!")





main()