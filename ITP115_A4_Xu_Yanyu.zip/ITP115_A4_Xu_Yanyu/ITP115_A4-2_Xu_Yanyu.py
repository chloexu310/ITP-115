#YANYU XU
#ITP 115, FALL 2019
#Assignment 4 Part 2
#yanyuxu@usc.edu
import random
def main():

    win = 0

    for roll in range(10):
        Case = random.randrange(1, 6)
        if Case == 1:
            print("You are playing for CASE 1, You will win for the following numbers: 1, 2, 3, 4, 5")
            print("Now rolling...")
            number = random.randrange(1,21)
            if number in range (5):
                win = win + 50
                print("You rolled a", number, "!")
                print("You won 50 points! :)")
            else:
                print("You rolled a", number)
                print("You didn't win :(")
        elif Case == 2:
            print("You are playing for CASE 2, You will win for the following numbers: 1, 3, 5, (...)15,17,19")
            print("Now rolling...")
            number1 = random.randrange(1, 21)
            if (number1 % 2) != 0:
                win = win + 50
                print("You rolled a", number1, "!")
                print("You won 50 points! :)")
            else:
                print("You rolled a", number1)
                print("You didn't win :(")

        elif Case == 3:
            print("You are playing for CASE 3, You will win for the following numbers: 5 6 7 8 9 10")
            print("Now rolling...")
            number2 = random.randrange(1,21)
            if number2 in range(5,10):
                win = win + 50
                print("You rolled a", number2, "!")
                print("You won 50 points! :)")
            else:
                print("You rolled a", number2)
                print("You didn't win :(")


        elif Case == 4:
            print("You are playing for CASE 4, You will win for the following numbers: 10 12 14 16 18 20")
            print("Now rolling...")
            number3 = random.randrange(1,21)
            if number3 >= 10 and (number3 % 2) == 0:
                win = win + 50
                print("You rolled a", number3, "!")
                print("You won 50 points! :)")
            else:
                print("You rolled a", number3)
                print("You didn't win :(")

        elif Case == 5:
            print("You are playing for CASE 5, You will win for the following numbers: 3 6 9 12 15 18")
            print("Now rolling...")
            number4 = random.randrange(1,21)
            if (number4%3) >= 1:
                win = win + 50
                print("You rolled a", number4, "!")
                print("You won 50 points! :)")
            else:
                print("You rolled a", number4)
                print("You didn't win :(")



    print("Your total score is:", win)
    print("Thanks for playing!")









main()