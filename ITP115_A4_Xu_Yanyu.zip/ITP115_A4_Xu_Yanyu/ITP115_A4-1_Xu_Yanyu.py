#YANYU XU
#ITP 115, FALL 2019
#Assignment 4 Part 1
#yanyuxu@usc.edu
def main():
    #generate user input
    sentence=input("Please enter a sentence: ")
    # define for the alphabet with lists
    alphabet = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n",
                "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]
    print("Here is the character distribution:")
    # take the count
    count = 0


    for letter in sentence.lower():
        if letter not in alphabet:
            count = count +1
    print("special characters" + ": " + "*" * count)


    for letter in alphabet:
        count = 0
        for output in sentence.lower():
            if letter == output:
                count = count + 1

        if count == 0:
            print(str(letter) + ": " + "None")
        elif count != 0:
            print(str(letter) + ": " + "*" * count)





main()