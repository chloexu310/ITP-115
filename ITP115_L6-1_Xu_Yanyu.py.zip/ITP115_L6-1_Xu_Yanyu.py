#Yanyu Xu
#ITP_115, FALL 2019
#LAB 6
#yanyuxu@usc.edu

def main():
    firstWordList = []
    secondWordList = []
    firstWord = input("Please enter a word or statement: ")
    firstWord = firstWord.lower()
    firstWordList.append(firstWord)
    secondWord = input("Please enter a word or statement: ")
    secondWord = secondWord.lower()
    secondWordList.append(secondWord)


    check = False
    if len(firstWordList) == len(secondWordList):
        for i in range(len(firstWordList)):
            if firstWordList[i] == secondWordList[i]:
                check = True
            else:
                check = False
    else:
        print("The two words you entered are not anagrams")
    if check == True:
        print("The two words you entered are anagrams")
    else:
        print("The two words you entered are not anagrams")


    str1 = ""

    firstWord = "".join(firstWord.split())
    secondWord = "".join(secondWord.split())
    for i in firstWord:
        str1 = i+str1
    if str1 == firstWord:
        print("The first word is a palindrome")
    else:
        print("The first word is not a palindrome")
    str2 = ""
    for i in secondWord:
        str2 = i + str2
    if str2 == secondWord:
        print("The first word is a palindrome")
    else:
        print("The first word is not a palindrome")


#I tried to test the palindrome, but I still confused about the palindrome

main()