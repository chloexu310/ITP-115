#Yanyu Xu
#ITP_115, FALL 2019
#Lab 8
#yanyuxu@usc.edu

#fn: temperatureConverter
#converts F>C or C>F
# input: int conversionType is 1 for F>C or 2 for C>F
#        float inputTemperature is temperature to convert
#return: float converted temperature
# side-effect: IS ANYTHING PRINTED?
#           prints error message if invalid type

def temperatureConverter(conversionType, inputTemperature):
    #assume that input parameters ALREADY EXIST
    if conversionType != 1 and conversionType != 2: #invalid
        print("Invalid type")
        return 0
    elif conversiontype == 1: #f > c
        cel = (inputTemperature -32) * 5/9
        return cel

    elif conversionType == 2: #c > f
        fah = (inputTemperature * 5/9) + 32
        return fah

#determine if user want to keep running program
#input : none
#return: True or False
# sude-effect: prints out message to continue and takes user input

def wantsToContinue():
    choice = input("Do you want to continue (y/n?")
    while choice.lower() != "y" and choice.lower() != "n":
        choice = input("Do you want to continue (y/n)? ")
    if choice.lower() == "y":
        return True
    else:
        return False

def main():
    #do while
    keepGoing = True
    while keepGoing == True:
        print("Welcome")
        choice = int(input("Enter 1 F>C or 2 C>F: "))
        temp = float(input("Enter temperature to convert: "))

        changedTemp = temperatureConverter(choice, temp)
        print("The converted temperature is", changedTemp)



main()
