#Yanyu Xu
#ITP_115, FALL 2019
#Lab 12-2
#yanyuxu@usc.edu

#from File import Class
from Coffee import Coffee


class Barista(object):
    MAX_ORDERS = 5

    def __init__(self, name):
        self.name = name
        #store a list of COFFEE thats empty
        orders = [Coffee]
        self.orders = orders
        self.statusIndex = 1

    def takeOrder(self):
        userName = input("Please enter your name:")
        typeDrink = input("What drink do you want?")
        sizeDrink = input("What size would you like?")
        print(sizeDrink, typeDrink, "for", userName, ("(ordered)"))

        class Coffee(object):
            def __init__(self, sizeDrink, typeDrink, userName):
                self.name = userName
                self.type = typeDrink
                self.size = sizeDrink

            def addCoffee(self):
                # if len(self.courses) >= 6:
                if self.getNumberOfDrink() >= MAX_ORDERS:
                    return False
                else:
                    self.orders.append(userName)
                    self.type.append(typeDrink)
                    self.size.append(sizeDrink)
                    return True

        self.orders.append(Coffee)



    #take coffee orders from the user as long as it is still accpt
    def isAcceptingOrders(self):
        if len(self.orders) >= 5:
            return False
        else:
            return True
    #it serves all drinks after accepting 5 orders
    def makeDrinks(self):
        self.statusIndex
        Coffee.setCompleted(self)

        #print out all orders
        print("Here are the completed orders")



        #reset the list to empty
        del self.orders[0]
        del self.orders[1]
        del self.orders[2]


    def __str__(self):
        msg = self.size + " " + self.desc + " for " + self.customer + "(" + Coffee.STATUSES[self.statusIndex] + ")"
        return msg





