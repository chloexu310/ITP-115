#Yanyu Xu
#ITP_115, FALL 2019
#Lab 12-2
#yanyuxu@usc.edu

class Coffee(object):
    STATUSES = ["ordered", "completed"]
    def __init__(self, inputSize, inputDesc, inputName):
        self.size = inputSize
        self.desc = inputDesc
        self.customer = inputName
        self.statusIndex = 0

    def setCompleted(self):
        self.statusIndex

    def __str__(self):
        msg = self.size + " " + self.desc + " for " + self.customer + "(" + Coffee.STATUSES[self.statusIndex] + ")"

        return msg
