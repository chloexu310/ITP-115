#Yanyu Xu
#ITP_115, FALL 2019
#LAB 6-2
#yanyuxu@usc.edu
def main():
    sentence = input("Please enter a sentence(including numbers):")
    letterList = sentence
    numberList = sentence


    for letter in sentence:
        if letter.isalpha():
            print("1", letterList)
            letterList = letterList.replace(letter, '-')
            print(letterList)

        if letter.isdigit():
            print("2", numberList)
            numberList = numberList(letter, '-')
            print(numberList)






    #temp = sentence
    #temp2 = sentence
    #for r in sentence:
      #  print(r)
        #if r.isalpha():
            #print("1",temp)
            #temp = temp.replace(r, '-')
        #if r.isdigit():
          #  print("2",temp2)
            #temp2 = temp2.replace(r, '-')

    #print(temp)
    #print(temp2)







main()